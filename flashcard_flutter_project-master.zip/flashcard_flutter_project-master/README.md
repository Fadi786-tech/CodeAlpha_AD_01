# flashcards_app

A simple Flashcard app.
Flashcards are a popular study tool that helps learners test and improves their memory when learning new information. A typical flashcard has two sides, with a question written on one side and the corresponding answer on the other side. For instance, the card's front side may ask, "What is Flutter," the backside provides the answer "UI framework for cross-platform application creation."

# Packages

flip_card:
font_awesome_flutter:

# Screenshot

![Screenshot_1644739038](https://user-images.githubusercontent.com/87958491/153744329-9d82798e-e0de-4dc4-ade9-97b6705b88bb.png)



## Getting Started

This project is a starting point for a Flutter application.

A few resources to get you started if this is your first Flutter project:

- [Lab: Write your first Flutter app](https://flutter.dev/docs/get-started/codelab)
- [Cookbook: Useful Flutter samples](https://flutter.dev/docs/cookbook)

For help getting started with Flutter, view our
[online documentation](https://flutter.dev/docs), which offers tutorials,
samples, guidance on mobile development, and a full API reference.
