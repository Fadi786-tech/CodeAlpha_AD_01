import 'package:flutter/material.dart';

const mainColor = Colors.pinkAccent;

const cardTextStyle = TextStyle(fontSize: 20, letterSpacing: 1.0);
const otherTextStyle = TextStyle(fontSize: 15);
